import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // chatbotviewmp9 (95:1547)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarwithnotchsfpnR (95:1554)
              margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 7*fem, 11*fem),
              width: double.infinity,
              height: 44*fem,
              child: Stack(
                children: [
                  Positioned(
                    // notchhbK (I95:1554;38:1665)
                    left: 78*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 219*fem,
                        height: 30*fem,
                        child: Image.asset(
                          'assets/page-1/images/notch-imT.png',
                          width: 219*fem,
                          height: 30*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // timeNxM (I95:1554;38:1666)
                    left: 32*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 26*fem,
                        height: 21*fem,
                        child: Text(
                          '9:41',
                          style: SafeGoogleFont (
                            'SF Pro Text',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.4*ffem/fem,
                            letterSpacing: -0.3199999928*fem,
                            color: Color(0xff020202),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // iosiconstatusbarQ8M (I95:1554;38:1667)
                    left: -8*fem,
                    top: 5*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                      width: 1929*fem,
                      height: 26*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // autogrouprvgyqzM (Mcutrecey91Mgg8yWCRVgy)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                            width: 48.96*fem,
                            height: 16*fem,
                          ),
                          Container(
                            // iosiconsmallmobilesignalYds (I95:1554;38:1667;9:6)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                            width: 17*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-mobile-signal-SJ9.png',
                              width: 17*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallwifiRBs (I95:1554;38:1667;9:12)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                            width: 15.27*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-wifi-kvR.png',
                              width: 15.27*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallbattery637 (I95:1554;38:1667;9:17)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                            width: 24.33*fem,
                            height: 11.33*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-battery-G85.png',
                              width: 24.33*fem,
                              height: 11.33*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupf9upktM (McupDnLews5nRzmoVoF9uP)
              padding: EdgeInsets.fromLTRB(8*fem, 5*fem, 13*fem, 5*fem),
              width: double.infinity,
              height: 50*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // iosicon24threelinemenudx9 (95:1555)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/page-1/images/ios-icon-24-three-line-menu-zKf.png',
                          width: 40*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // selectednotessbb (95:1582)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19*fem, 0*fem),
                    child: Text(
                      'Selected Notes',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 24*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.5*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupgbr5Lzy (McupVSZEJ8k7ycV946GBr5)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 3*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 5*fem, 15*fem, 5*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff8073ff),
                      borderRadius: BorderRadius.circular(22*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // egr102bR7 (138:2100)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          child: Text(
                            'EGR 102',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        Container(
                          // arrowdownsigntonavigate21GXF (138:2218)
                          width: 20*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/page-1/images/arrow-down-sign-to-navigate-2-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup11ghxus (McurQdrx8k4T4mSCVV11Gh)
              padding: EdgeInsets.fromLTRB(28*fem, 18*fem, 28*fem, 23*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupve3ffZP (McupkgcqE7L3ZAULzfVE3f)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 13*fem),
                    padding: EdgeInsets.fromLTRB(15*fem, 20*fem, 4*fem, 1*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xfff4f4f4),
                      borderRadius: BorderRadius.circular(20*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/mask-group-8Hj.png',
                        ),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x19000000),
                          offset: Offset(0*fem, 0*fem),
                          blurRadius: 4*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupzsfxtBF (Mcuq3qnuge4fnDCZAkZSfX)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                          width: double.infinity,
                          height: 469*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupxtnrnXX (McuqHvDneC333yxCBhxtnR)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                width: 303*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupmbwdgcu (McuqUQvJQ1Z3p14JWGMBWd)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18*fem),
                                      width: double.infinity,
                                      height: 301*fem,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xff8073ff)),
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(16*fem),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x0c000000),
                                            offset: Offset(0*fem, 0*fem),
                                            blurRadius: 4*fem,
                                          ),
                                        ],
                                      ),
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // minsXdX (138:2222)
                                            left: 14*fem,
                                            top: 25*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 278*fem,
                                                height: 268*fem,
                                                child: Text(
                                                  'Borem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus urna at turpis condimentum lobortis. Ut commodo efficitur neque. Ut diam quam, semper iaculis condimentum ac, vestibulum eu nisl. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.Class aptent taciti sociosqu ad litora torquent per conubia nostra, per incas',
                                                  style: SafeGoogleFont (
                                                    'Open Sans',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.3625*ffem/fem,
                                                    letterSpacing: 0.1000000015*fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // chatgpta61 (138:2223)
                                            left: 13*fem,
                                            top: 4*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 71*fem,
                                                height: 23*fem,
                                                child: Text(
                                                  'ChatGPT:',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 15*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.5*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // autogroupowooDuf (Mcuqak55xtJvuNu6fcoWoo)
                                      width: double.infinity,
                                      height: 150*fem,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xff8073ff)),
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(16*fem),
                                      ),
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // minsibX (138:2226)
                                            left: 14*fem,
                                            top: 25*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 278*fem,
                                                height: 115*fem,
                                                child: Text(
                                                  'Borem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus',
                                                  style: SafeGoogleFont (
                                                    'Open Sans',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.3625*ffem/fem,
                                                    letterSpacing: 0.1000000015*fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // youm41 (138:2227)
                                            left: 14*fem,
                                            top: 4*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 33*fem,
                                                height: 23*fem,
                                                child: Text(
                                                  'You:',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 15*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.5*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // rectangle55ReM (138:2228)
                                margin: EdgeInsets.fromLTRB(0*fem, 59*fem, 0*fem, 0*fem),
                                width: 2*fem,
                                height: 238*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(20*fem),
                                  color: Color(0xffc8c8c8),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupzxiuv5K (Mcuqt4uYzLGvKFWxgnzXiu)
                          margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 25*fem, 0*fem),
                          width: double.infinity,
                          height: 79*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // minspgV (138:2233)
                                left: 1*fem,
                                top: 21*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 275*fem,
                                    height: 58*fem,
                                    child: Text(
                                      'Borem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et per conubia nostra, per incas  vulputate',
                                      style: SafeGoogleFont (
                                        'Open Sans',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.3625*ffem/fem,
                                        letterSpacing: 0.1000000015*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // chatgptHKB (138:2234)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 71*fem,
                                    height: 23*fem,
                                    child: Text(
                                      'ChatGPT:',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // inputfieldjgy (95:1584)
                    margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 4*fem, 19*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(16*fem, 13.09*fem, 16*fem, 10.91*fem),
                        width: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xffd4d7de)),
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(16*fem),
                        ),
                        child: Text(
                          'Ask ChatGTP',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            color: Color(0xff323940),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupvvff7xR (McurDyW3p1K57vSSKqVvFF)
                    margin: EdgeInsets.fromLTRB(43*fem, 0*fem, 36*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // wantfasterresponsesq7j (138:2238)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                          child: Text(
                            'Want faster responses?',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.25*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Text(
                          // upgradehereutH (138:2239)
                          'Upgrade here',
                          textAlign: TextAlign.right,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.25*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}