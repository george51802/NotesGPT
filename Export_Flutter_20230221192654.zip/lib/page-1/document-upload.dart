import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // documentuploadgnq (94:1721)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupqpdxBUh (Mcui1dMRuet2tqP3h3qPDX)
              padding: EdgeInsets.fromLTRB(8*fem, 0*fem, 7*fem, 19*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // iosstatusbarwithnotchsfTSD (94:1728)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                    width: double.infinity,
                    height: 44*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // notchjuX (I94:1728;38:1665)
                          left: 78*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 219*fem,
                              height: 30*fem,
                              child: Image.asset(
                                'assets/page-1/images/notch-ndB.png',
                                width: 219*fem,
                                height: 30*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // time1MF (I94:1728;38:1666)
                          left: 32*fem,
                          top: 13*fem,
                          child: Align(
                            child: SizedBox(
                              width: 26*fem,
                              height: 21*fem,
                              child: Text(
                                '9:41',
                                style: SafeGoogleFont (
                                  'SF Pro Text',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.4*ffem/fem,
                                  letterSpacing: -0.3199999928*fem,
                                  color: Color(0xff020202),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // iosiconstatusbardtR (I94:1728;38:1667)
                          left: -8*fem,
                          top: 5*fem,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                            width: 1929*fem,
                            height: 26*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogrouppdyfGwP (McuiGcvSzFcuh9XmrzPDyF)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                                  width: 48.96*fem,
                                  height: 16*fem,
                                ),
                                Container(
                                  // iosiconsmallmobilesignalAms (I94:1728;38:1667;9:6)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                                  width: 17*fem,
                                  height: 10.67*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ios-icon-small-mobile-signal-VJu.png',
                                    width: 17*fem,
                                    height: 10.67*fem,
                                  ),
                                ),
                                Container(
                                  // iosiconsmallwifiprR (I94:1728;38:1667;9:12)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                                  width: 15.27*fem,
                                  height: 10.97*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ios-icon-small-wifi-NAy.png',
                                    width: 15.27*fem,
                                    height: 10.97*fem,
                                  ),
                                ),
                                Container(
                                  // iosiconsmallbatteryJFo (I94:1728;38:1667;9:17)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                                  width: 24.33*fem,
                                  height: 11.33*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ios-icon-small-battery-Zd7.png',
                                    width: 24.33*fem,
                                    height: 11.33*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupasczAJ1 (McuhYPdp7bhosqGrp8AscZ)
                    margin: EdgeInsets.fromLTRB(7*fem, 0*fem, 122*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // iosicon24threelinemenu3sb (184:1566)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/ios-icon-24-three-line-menu-beD.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // uploadcontentGEZ (184:1567)
                          'Upload Content',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup5y9oYxm (McuhiDgmbkJMtYpMkL5y9o)
              width: double.infinity,
              height: 790*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle704RK (184:1555)
                    left: 0*fem,
                    top: 576*fem,
                    child: Align(
                      child: SizedBox(
                        width: 537*fem,
                        height: 214*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            gradient: LinearGradient (
                              begin: Alignment(0, -1),
                              end: Alignment(0, 1),
                              colors: <Color>[Color(0xff9869ff), Color(0xff7575ff)],
                              stops: <double>[0, 1],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle71Uzq (184:1556)
                    left: 32*fem,
                    top: 637*fem,
                    child: Align(
                      child: SizedBox(
                        width: 111*fem,
                        height: 46*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(23*fem),
                            color: Color(0x99000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // scankBf (184:1557)
                    left: 62*fem,
                    top: 645*fem,
                    child: Align(
                      child: SizedBox(
                        width: 52*fem,
                        height: 30*fem,
                        child: Text(
                          'Scan',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle72QGD (184:1560)
                    left: 246*fem,
                    top: 636*fem,
                    child: Align(
                      child: SizedBox(
                        width: 111*fem,
                        height: 46*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(23*fem),
                            color: Color(0x99000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // uploadJ6h (184:1561)
                    left: 265*fem,
                    top: 645*fem,
                    child: Align(
                      child: SizedBox(
                        width: 74*fem,
                        height: 30*fem,
                        child: Text(
                          'Upload',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse195wvM (184:1558)
                    left: 162*fem,
                    top: 627*fem,
                    child: Align(
                      child: SizedBox(
                        width: 65*fem,
                        height: 65*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(32.5*fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse1961vD (184:1559)
                    left: 171*fem,
                    top: 636*fem,
                    child: Align(
                      child: SizedBox(
                        width: 47*fem,
                        height: 47*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(23.5*fem),
                            color: Color(0xffcfcfcf),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x26000000),
                                offset: Offset(0*fem, 0*fem),
                                blurRadius: 10*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image6SEq (184:1564)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 410.87*fem,
                        height: 593.81*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-6.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}