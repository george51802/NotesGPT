import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // loginuT3 (61:1822)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarmodalstacksfQPo (61:1838)
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff020202),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupowbs7JD (McvFYiohaj4tK1jkbnowBs)
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupuf5wSLV (McvF2QLtHh8QLjezZjUf5w)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 7*fem),
                          width: 1929*fem,
                          height: 36*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // notchioo (I61:1838;33:1673)
                                left: 85*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 219*fem,
                                    height: 30*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/notch-3Ch.png',
                                      width: 219*fem,
                                      height: 30*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // time1H7 (I61:1838;33:1674)
                                left: 32*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 26*fem,
                                    height: 21*fem,
                                    child: Text(
                                      '9:41',
                                      style: SafeGoogleFont (
                                        'SF Pro Text',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.4*ffem/fem,
                                        letterSpacing: -0.3199999928*fem,
                                        color: Color(0xfffafafa),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // iosiconstatusbarFx9 (I61:1838;33:1675)
                                left: 0*fem,
                                top: 5*fem,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                                  width: 1929*fem,
                                  height: 26*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xff020202),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Container(
                                        // autogrouppvxfVrV (McvFEypG8z2Uw5PkxtpvXf)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                                        width: 48.96*fem,
                                        height: 16*fem,
                                      ),
                                      Container(
                                        // iosiconsmallmobilesignaloMP (I61:1838;33:1675;9:6)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                                        width: 17*fem,
                                        height: 10.67*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ios-icon-small-mobile-signal-6w7.png',
                                          width: 17*fem,
                                          height: 10.67*fem,
                                        ),
                                      ),
                                      Container(
                                        // iosiconsmallwifiGVs (I61:1838;33:1675;9:12)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                                        width: 15.27*fem,
                                        height: 10.97*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ios-icon-small-wifi-jqf.png',
                                          width: 15.27*fem,
                                          height: 10.97*fem,
                                        ),
                                      ),
                                      Container(
                                        // iosiconsmallbatteryLkd (I61:1838;33:1675;9:17)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                                        width: 24.33*fem,
                                        height: 11.33*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ios-icon-small-battery-dn5.png',
                                          width: 24.33*fem,
                                          height: 11.33*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // secondpagecTF (I61:1838;33:1677)
                          margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                          width: double.infinity,
                          height: 10*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff9e9e9e),
                            borderRadius: BorderRadius.only (
                              topLeft: Radius.circular(10*fem),
                              topRight: Radius.circular(10*fem),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // firstpageHZP (I61:1838;33:1676)
                    width: double.infinity,
                    height: 14*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(10*fem),
                        topRight: Radius.circular(10*fem),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupacguyh7 (McvDq2ApuSem6qEiZVACGu)
              padding: EdgeInsets.fromLTRB(19*fem, 82*fem, 0*fem, 32*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // notesgpt011GAR (138:1881)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 30*fem),
                    width: 303*fem,
                    height: 65*fem,
                    child: Image.asset(
                      'assets/page-1/images/notesgpt-01-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // login9zu (138:1945)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 283*fem, 38*fem),
                    child: Text(
                      'Log in',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 30*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.3*ffem/fem,
                        letterSpacing: -0.3*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // input2oo (138:1962)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22*fem),
                    width: 353*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // title869 (I138:1962;16:183)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                          child: Text(
                            'Email address',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.25*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // inputfieldcGD (I138:1962;18:227)
                          padding: EdgeInsets.fromLTRB(16*fem, 18*fem, 16*fem, 18*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xffd8dadc)),
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // text6SH (I138:1962;16:184)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 131*fem, 0*fem),
                                child: Text(
                                  'helloworld@gmail.com',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.25*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Container(
                                // iconAS9 (I138:1962;20:223)
                                width: 20*fem,
                                height: 20*fem,
                                child: Image.asset(
                                  'assets/page-1/images/icon-8u3.png',
                                  width: 20*fem,
                                  height: 20*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupmgp7Gk5 (McvCidrSYj65ThY1wtMgP7)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 38*fem),
                    width: 353*fem,
                    height: 113*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // forgotpasswordAqT (138:1946)
                          left: 234*fem,
                          top: 95*fem,
                          child: Align(
                            child: SizedBox(
                              width: 119*fem,
                              height: 18*fem,
                              child: Text(
                                'Forgot password?',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.25*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // inputpv1 (138:1952)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22*fem),
                            width: 353*fem,
                            height: 102*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // titletus (I138:1952;16:183)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: Text(
                                    'Password',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.25*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // inputfieldnVT (I138:1952;18:227)
                                  padding: EdgeInsets.fromLTRB(16*fem, 20*fem, 18*fem, 21*fem),
                                  width: double.infinity,
                                  height: 56*fem,
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xffd8dadc)),
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // group36690TLh (138:1953)
                                        margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 226*fem, 4*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // ellipse1869DX (138:1954)
                                              width: 6*fem,
                                              height: 6*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(3*fem),
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 4*fem,
                                            ),
                                            Container(
                                              // ellipse187341 (138:1955)
                                              width: 6*fem,
                                              height: 6*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(3*fem),
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 4*fem,
                                            ),
                                            Container(
                                              // ellipse188YFf (138:1956)
                                              width: 6*fem,
                                              height: 6*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(3*fem),
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 4*fem,
                                            ),
                                            Container(
                                              // ellipse1893iD (138:1957)
                                              width: 6*fem,
                                              height: 6*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(3*fem),
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 4*fem,
                                            ),
                                            Container(
                                              // ellipse190xKP (138:1958)
                                              width: 6*fem,
                                              height: 6*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(3*fem),
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 4*fem,
                                            ),
                                            Container(
                                              // ellipse191rvZ (138:1959)
                                              width: 6*fem,
                                              height: 6*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(3*fem),
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 4*fem,
                                            ),
                                            Container(
                                              // ellipse192abf (138:1960)
                                              width: 6*fem,
                                              height: 6*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(3*fem),
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 4*fem,
                                            ),
                                            Container(
                                              // ellipse1936K7 (138:1961)
                                              width: 6*fem,
                                              height: 6*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(3*fem),
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // iconRcH (I138:1952;20:223)
                                        width: 17*fem,
                                        height: 15*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-B4H.png',
                                          width: 17*fem,
                                          height: 15*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // buttonprimarykPf (138:1951)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 38*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 353*fem,
                        height: 56*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff000000),
                          borderRadius: BorderRadius.circular(10*fem),
                        ),
                        child: Center(
                          child: Center(
                            child: Text(
                              'Log in',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.25*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupqn4muvm (McvDD3CnKCsrnUsmkRqn4m)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 22*fem),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // line21pnq (138:1950)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          width: 122*fem,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd8dadc),
                          ),
                        ),
                        SizedBox(
                          width: 10*fem,
                        ),
                        Text(
                          // orloginwithhLq (138:1948)
                          'Or Login with',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.25*ffem/fem,
                            color: Color(0xb2000000),
                          ),
                        ),
                        SizedBox(
                          width: 10*fem,
                        ),
                        Container(
                          // line20oPs (138:1949)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          width: 122*fem,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd8dadc),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupe4nyWp5 (McvDPXuJ52PsYVyt4zE4ny)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                    width: 387*fem,
                    height: 56*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // buttonwithcenterediconDTb (138:1963)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(44*fem, 18*fem, 0*fem, 18*fem),
                            width: 142*fem,
                            height: 56*fem,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffd8dadc)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Container(
                              // frame366954z1 (I138:1963;31:495)
                              padding: EdgeInsets.fromLTRB(6*fem, 1*fem, 6*fem, 1*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Align(
                                // socialiconfacebooknQD (I138:1963;31:489)
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  width: 8.96*fem,
                                  height: 18*fem,
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 77.04*fem, 0*fem),
                                    child: Image.asset(
                                      'assets/page-1/images/social-icon-facebook.png',
                                      width: 8.96*fem,
                                      height: 18*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // buttonwithcenterediconFYh (138:1964)
                          left: 123*fem,
                          top: 0*fem,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(44*fem, 18*fem, 0*fem, 18*fem),
                            width: 142*fem,
                            height: 56*fem,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffd8dadc)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Container(
                              // frame366957qo (I138:1964;31:495)
                              padding: EdgeInsets.fromLTRB(1*fem, 0*fem, 1*fem, 0*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Align(
                                // socialicongoogler2h (I138:1964;31:489)
                                alignment: Alignment.topLeft,
                                child: SizedBox(
                                  width: 18.17*fem,
                                  height: 19*fem,
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 77.83*fem, 1*fem),
                                    child: Image.asset(
                                      'assets/page-1/images/social-icon-google-3vV.png',
                                      width: 18.17*fem,
                                      height: 19*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // buttonwithcenteredicon5w3 (138:1965)
                          left: 245*fem,
                          top: 0*fem,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(44*fem, 18*fem, 0*fem, 18*fem),
                            width: 142*fem,
                            height: 56*fem,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffd8dadc)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Container(
                              // frame36695wiM (I138:1965;31:495)
                              padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 2*fem, 0*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Align(
                                // socialiconappleGVj (I138:1965;31:489)
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  width: 16.53*fem,
                                  height: 19.93*fem,
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 77.47*fem, 0.07*fem),
                                    child: Image.asset(
                                      'assets/page-1/images/social-icon-apple-Fzm.png',
                                      width: 16.53*fem,
                                      height: 19.93*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // donthaveanaccountsignupisX (138:1947)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19*fem, 0*fem),
                    child: RichText(
                      text: TextSpan(
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.25*ffem/fem,
                          color: Color(0xff000000),
                        ),
                        children: [
                          TextSpan(
                            text: 'Don’t have an account?',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.25*ffem/fem,
                              color: Color(0xb2000000),
                            ),
                          ),
                          TextSpan(
                            text: ' ',
                          ),
                          TextSpan(
                            text: 'Sign up',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.25*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}