import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // menuV25 (47:1693)
        padding: EdgeInsets.fromLTRB(8*fem, 0*fem, 7*fem, 38*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0, -1),
            end: Alignment(0, 1),
            colors: <Color>[Color(0xff9b68ff), Color(0xff667aff)],
            stops: <double>[0, 1],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarwithnotchsf5W5 (47:1700)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 36*fem),
              width: double.infinity,
              height: 44*fem,
              child: Stack(
                children: [
                  Positioned(
                    // timey5f (I47:1700;38:1666)
                    left: 32*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 26*fem,
                        height: 21*fem,
                        child: Text(
                          '9:41',
                          style: SafeGoogleFont (
                            'SF Pro Text',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.4*ffem/fem,
                            letterSpacing: -0.3199999928*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // iosiconstatusbarPfB (I47:1700;38:1667)
                    left: -8*fem,
                    top: 5*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                      width: 1929*fem,
                      height: 26*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // autogrouphycz3zd (Mcv9etdGyUDKJgJmtkHyCZ)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                            width: 48.96*fem,
                            height: 16*fem,
                          ),
                          Container(
                            // iosiconsmallmobilesignalYgV (I47:1700;38:1667;9:6)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                            width: 17*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-mobile-signal-SYV.png',
                              width: 17*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallwifi1py (I47:1700;38:1667;9:12)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                            width: 15.27*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-wifi-XF3.png',
                              width: 15.27*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallbatteryttm (I47:1700;38:1667;9:17)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                            width: 24.33*fem,
                            height: 11.33*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-battery-UZ3.png',
                              width: 24.33*fem,
                              height: 11.33*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup8fmfMnM (Mcv5HgZrJTx5bcewSe8fMf)
              margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 17*fem, 23*fem),
              width: double.infinity,
              height: 47*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupt5rp4gm (Mcv5b6EWcNXkbuDdPMt5RP)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 90*fem, 0*fem),
                    width: 208*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // groupNSZ (184:1136)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            width: 208*fem,
                            height: 47*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // hellovarabygCM (184:1137)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
                                  child: Text(
                                    'Hello, Alex',
                                    style: SafeGoogleFont (
                                      'Open Sans',
                                      fontSize: 18*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.3625*ffem/fem,
                                      letterSpacing: 0.1285714358*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Text(
                                  // findacourseyouwa95w (184:1138)
                                  'Begin your note taking journey',
                                  style: SafeGoogleFont (
                                    'Open Sans',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    letterSpacing: 0.1000000015*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // hellovaraby2fX (184:1177)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 97*fem,
                              height: 25*fem,
                              child: Text(
                                'Hello, Alex',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1285714358*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouphxzygk5 (Mcv5mW6q5jS5mWNunNhxzy)
                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 1*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/mask-group-fEu.png',
                        ),
                      ),
                    ),
                    child: Center(
                      // maskgroupBgq (184:1181)
                      child: SizedBox(
                        width: 45*fem,
                        height: 45*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/mask-group-ipd.png',
                            width: 45*fem,
                            height: 45*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup9sqmUA9 (Mcv5yVkqwp2PCxVtij9SQM)
              margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 17*fem, 29*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(28*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 8*fem),
                    blurRadius: 20*fem,
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Positioned(
                    // KRf (184:1148)
                    left: 30.3885498047*fem,
                    top: 20.0742797852*fem,
                    child: Align(
                      child: SizedBox(
                        width: 15.22*fem,
                        height: 16.14*fem,
                        child: Image.asset(
                          'assets/page-1/images/.png',
                          width: 15.22*fem,
                          height: 16.14*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // searchforanythingnKF (184:1151)
                    left: 62*fem,
                    top: 19*fem,
                    child: Align(
                      child: SizedBox(
                        width: 109*fem,
                        height: 18*fem,
                        child: Text(
                          'Ask me anything...',
                          style: SafeGoogleFont (
                            'Source Sans Pro',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2575*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff595a73),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectanglesk1 (184:1187)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 343*fem,
                        height: 56*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(28*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x0c000000),
                                offset: Offset(0*fem, 8*fem),
                                blurRadius: 20*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // 7eM (184:1188)
                    left: 30.3885498047*fem,
                    top: 20.0742797852*fem,
                    child: Align(
                      child: SizedBox(
                        width: 15.22*fem,
                        height: 16.14*fem,
                        child: Image.asset(
                          'assets/page-1/images/-QMj.png',
                          width: 15.22*fem,
                          height: 16.14*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // searchforanythingoGH (184:1191)
                    left: 62*fem,
                    top: 19*fem,
                    child: Align(
                      child: SizedBox(
                        width: 96*fem,
                        height: 18*fem,
                        child: Text(
                          'Search for notes',
                          style: SafeGoogleFont (
                            'Source Sans Pro',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2575*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff595a73),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupv1rmrkM (Mcv6LV9sTT4Qizi7Mqv1rm)
              margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 18*fem, 16*fem),
              width: double.infinity,
              height: 25*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouputtskqj (Mcv6bPthFbBbvtv1cEuTTs)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 204*fem, 0*fem),
                    width: 84*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // categoriesfho (184:1139)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 84*fem,
                              height: 25*fem,
                              child: Text(
                                'My Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1285714358*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // categoriesw9X (184:1179)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 84*fem,
                              height: 25*fem,
                              child: Text(
                                'My Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1285714358*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupezybbUy (Mcv6gj59QxZHuKQth4ezyb)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 2*fem),
                    width: 54*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // viewallW69 (184:1140)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 54*fem,
                              height: 20*fem,
                              child: Text(
                                'View All',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // viewallAAh (184:1180)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 54*fem,
                              height: 20*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Text(
                                  'View All',
                                  style: SafeGoogleFont (
                                    'Open Sans',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.3625*ffem/fem,
                                    letterSpacing: 0.1000000015*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcqjkoDf (Mcv6wieAVZJAhdZcs1CqjK)
              margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 19*fem, 11*fem),
              width: double.infinity,
              height: 78*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouppbc1Jw7 (Mcv7Ld9fXkUtsAWqjdpbc1)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                    width: 163*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(7*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x0c000000),
                          offset: Offset(0*fem, 8*fem),
                          blurRadius: 20*fem,
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // codingxEy (184:1165)
                          left: 19*fem,
                          top: 19*fem,
                          child: Align(
                            child: SizedBox(
                              width: 91*fem,
                              height: 22*fem,
                              child: Text(
                                'Class Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1142857149*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // courseDRo (184:1166)
                          left: 19*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 59*fem,
                              height: 20*fem,
                              child: Text(
                                '12 Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleUMj (184:1204)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 163*fem,
                              height: 78*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(7*fem),
                                    color: Color(0xffffffff),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x0c000000),
                                        offset: Offset(0*fem, 8*fem),
                                        blurRadius: 20*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // coding8BP (184:1205)
                          left: 19*fem,
                          top: 19*fem,
                          child: Align(
                            child: SizedBox(
                              width: 91*fem,
                              height: 22*fem,
                              child: Text(
                                'Class Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1142857149*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // coursenmj (184:1206)
                          left: 19*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 59*fem,
                              height: 20*fem,
                              child: Text(
                                '12 Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupfeahfqX (Mcv7ackMCqqaYXKeq3feaH)
                    width: 163*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(7*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x0c000000),
                          offset: Offset(0*fem, 8*fem),
                          blurRadius: 20*fem,
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // codingLRs (184:1168)
                          left: 19*fem,
                          top: 19*fem,
                          child: Align(
                            child: SizedBox(
                              width: 115*fem,
                              height: 22*fem,
                              child: Text(
                                'Meeting Notes\n',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1142857149*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // courseCU5 (184:1169)
                          left: 19*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 59*fem,
                              height: 20*fem,
                              child: Text(
                                '12 Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectanglegu3 (184:1207)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 163*fem,
                              height: 78*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(7*fem),
                                    color: Color(0xffffffff),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x0c000000),
                                        offset: Offset(0*fem, 8*fem),
                                        blurRadius: 20*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // codingMEV (184:1208)
                          left: 19*fem,
                          top: 19*fem,
                          child: Align(
                            child: SizedBox(
                              width: 115*fem,
                              height: 22*fem,
                              child: Text(
                                'Meeting Notes\n',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1142857149*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // courseRk9 (184:1209)
                          left: 19*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 59*fem,
                              height: 20*fem,
                              child: Text(
                                '12 Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupro5otdj (Mcv7zSPzN5npEbfxrfRo5o)
              margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 18*fem, 31*fem),
              width: double.infinity,
              height: 78*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupancdbo3 (Mcv8LgKGKbHhQvNkBtAnCd)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                    width: 163*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(7*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x0c000000),
                          offset: Offset(0*fem, 8*fem),
                          blurRadius: 20*fem,
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // codingrDB (184:1171)
                          left: 19*fem,
                          top: 19*fem,
                          child: Align(
                            child: SizedBox(
                              width: 59*fem,
                              height: 22*fem,
                              child: Text(
                                'EGR102',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1142857149*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // courseuhF (184:1172)
                          left: 19*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 51*fem,
                              height: 20*fem,
                              child: Text(
                                '4 Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleUtm (184:1210)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 163*fem,
                              height: 78*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(7*fem),
                                    color: Color(0xffffffff),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x0c000000),
                                        offset: Offset(0*fem, 8*fem),
                                        blurRadius: 20*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // codingLRB (184:1211)
                          left: 19*fem,
                          top: 19*fem,
                          child: Align(
                            child: SizedBox(
                              width: 59*fem,
                              height: 22*fem,
                              child: Text(
                                'EGR102',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1142857149*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // coursep5T (184:1212)
                          left: 19*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 51*fem,
                              height: 20*fem,
                              child: Text(
                                '4 Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouputpztb7 (Mcv8XfzwnAVojR9p3huTpZ)
                    width: 163*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(7*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x0c000000),
                          offset: Offset(0*fem, 8*fem),
                          blurRadius: 20*fem,
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // codingmQ1 (184:1174)
                          left: 19*fem,
                          top: 19*fem,
                          child: Align(
                            child: SizedBox(
                              width: 89*fem,
                              height: 22*fem,
                              child: Text(
                                'Family Talk\n',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1142857149*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // courseeCu (184:1175)
                          left: 19*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 51*fem,
                              height: 20*fem,
                              child: Text(
                                '2 Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangleVjK (184:1213)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 163*fem,
                              height: 78*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(7*fem),
                                    color: Color(0xffffffff),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x0c000000),
                                        offset: Offset(0*fem, 8*fem),
                                        blurRadius: 20*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // coding1r5 (184:1214)
                          left: 19*fem,
                          top: 19*fem,
                          child: Align(
                            child: SizedBox(
                              width: 89*fem,
                              height: 22*fem,
                              child: Text(
                                'Family Talk\n',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1142857149*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // coursea21 (184:1215)
                          left: 19*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 51*fem,
                              height: 20*fem,
                              child: Text(
                                '2 Notes',
                                style: SafeGoogleFont (
                                  'Open Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  letterSpacing: 0.1000000015*fem,
                                  color: Color(0xff101436),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupssgvHqX (Mcv8tL5C9y56soaizeSSgV)
              margin: EdgeInsets.fromLTRB(106*fem, 0*fem, 108*fem, 20*fem),
              width: double.infinity,
              height: 39*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(31*fem),
                gradient: LinearGradient (
                  begin: Alignment(-2.212, 1.607),
                  end: Alignment(0.999, 1.607),
                  colors: <Color>[Color(0xffff8e5a), Color(0xffffc862)],
                  stops: <double>[0, 1],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x6effbe89),
                    offset: Offset(0*fem, 6*fem),
                    blurRadius: 5.5*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Upgrade to Gold',
                  style: SafeGoogleFont (
                    'Open Sans',
                    fontSize: 13*ffem,
                    fontWeight: FontWeight.w600,
                    height: 1.3625*ffem/fem,
                    letterSpacing: 0.1428571492*fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
            Container(
              // customerperspectivexaH (184:1219)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 221*fem, 5*fem),
              child: Text(
                'Ask ChatGPT',
                style: SafeGoogleFont (
                  'Open Sans',
                  fontSize: 16*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.3625*ffem/fem,
                  letterSpacing: 0.1142857149*fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogrouppzwd35w (Mcv925MHYeHb4CVZrFPZWD)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 18*fem),
              width: 330*fem,
              height: 166*fem,
              child: Image.asset(
                'assets/page-1/images/auto-group-pzwd.png',
                width: 330*fem,
                height: 166*fem,
              ),
            ),
            Container(
              // autogroupzhsdiC5 (Mcv99KeDEZoyg7jTAazHSD)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
              width: 343*fem,
              height: 62*fem,
              child: Image.asset(
                'assets/page-1/images/auto-group-zhsd.png',
                width: 343*fem,
                height: 62*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}