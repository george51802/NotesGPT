import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // newnote3L9 (184:1606)
        padding: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarwithnotchsfJWy (184:1607)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 33*fem),
              width: 375*fem,
              height: 44*fem,
              child: Stack(
                children: [
                  Positioned(
                    // notchmfT (I184:1607;38:1665)
                    left: 78*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 219*fem,
                        height: 30*fem,
                        child: Image.asset(
                          'assets/page-1/images/notch.png',
                          width: 219*fem,
                          height: 30*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // timeSmb (I184:1607;38:1666)
                    left: 32*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 26*fem,
                        height: 21*fem,
                        child: Text(
                          '9:41',
                          style: SafeGoogleFont (
                            'SF Pro Text',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.4*ffem/fem,
                            letterSpacing: -0.3199999928*fem,
                            color: Color(0xff020202),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // iosiconstatusbarUiH (I184:1607;38:1667)
                    left: -8*fem,
                    top: 5*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                      width: 1929*fem,
                      height: 26*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // autogroupwwxfmL1 (McunfukjkjGDEXpGPhWWXf)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                            width: 48.96*fem,
                            height: 16*fem,
                          ),
                          Container(
                            // iosiconsmallmobilesignal4pu (I184:1607;38:1667;9:6)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                            width: 17*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-mobile-signal-vtu.png',
                              width: 17*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallwifivs7 (I184:1607;38:1667;9:12)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                            width: 15.27*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-wifi-CRT.png',
                              width: 15.27*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallbatteryBo3 (I184:1607;38:1667;9:17)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                            width: 24.33*fem,
                            height: 11.33*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-battery-imT.png',
                              width: 24.33*fem,
                              height: 11.33*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupj7a5eRj (McumNHG664eNVfW29eJ7a5)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 146*fem, 34*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // iosicon24threelinemenuYX7 (184:1632)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/page-1/images/ios-icon-24-three-line-menu-797.png',
                          width: 40*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Text(
                    // noteslibraryaTo (184:1633)
                    'Notes Library',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.5*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group36696fk9 (184:1608)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 34*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(38.23*fem, 17.78*fem, 25.33*fem, 11.82*fem),
              width: double.infinity,
              height: 73*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff8073ff)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(7*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 8*fem),
                    blurRadius: 20*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group366953Vo (184:1610)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 156.77*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // codingMFb (184:1611)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.4*fem),
                          child: Text(
                            'Class Notes',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1142857149*fem,
                              color: Color(0xff101436),
                            ),
                          ),
                        ),
                        Text(
                          // courseDob (184:1612)
                          '12 Notes',
                          style: SafeGoogleFont (
                            'Open Sans',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // vector8vZ (184:1613)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.96*fem),
                    width: 16.67*fem,
                    height: 27*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector.png',
                      width: 16.67*fem,
                      height: 27*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group366972FF (184:1614)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 34*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(38.23*fem, 17.78*fem, 25.33*fem, 11.82*fem),
              width: double.infinity,
              height: 73*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff8073ff)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(7*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 8*fem),
                    blurRadius: 20*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group36695pgu (184:1616)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 132.77*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // codingwFj (184:1617)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.4*fem),
                          child: Text(
                            'Meeting Notes',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1142857149*fem,
                              color: Color(0xff101436),
                            ),
                          ),
                        ),
                        Text(
                          // coursepKX (184:1618)
                          '12 Notes',
                          style: SafeGoogleFont (
                            'Open Sans',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // vector85K (184:1619)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.96*fem),
                    width: 16.67*fem,
                    height: 27*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-E4D.png',
                      width: 16.67*fem,
                      height: 27*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group36698cmB (184:1620)
              margin: EdgeInsets.fromLTRB(19*fem, 0*fem, 35*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(38.23*fem, 17.78*fem, 25.33*fem, 11.82*fem),
              width: double.infinity,
              height: 73*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff8073ff)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(7*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 8*fem),
                    blurRadius: 20*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group36695q89 (184:1622)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 188.77*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // codingwS5 (184:1623)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.4*fem),
                          child: Text(
                            'EGR102',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1142857149*fem,
                              color: Color(0xff101436),
                            ),
                          ),
                        ),
                        Text(
                          // courseCso (184:1624)
                          '4 Notes',
                          style: SafeGoogleFont (
                            'Open Sans',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // vector6yB (184:1625)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.96*fem),
                    width: 16.67*fem,
                    height: 27*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-sbB.png',
                      width: 16.67*fem,
                      height: 27*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouppeydnb7 (McumpbqZm545z8D7sapEYD)
              width: 403*fem,
              height: 459*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group36699Tx9 (184:1626)
                    left: 19*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(38.23*fem, 17.78*fem, 25.33*fem, 11.82*fem),
                      width: 328*fem,
                      height: 73*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xff8073ff)),
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(7*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x0c000000),
                            offset: Offset(0*fem, 8*fem),
                            blurRadius: 20*fem,
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group36695Ys7 (184:1628)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 159.77*fem, 0*fem),
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // coding44m (184:1629)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.4*fem),
                                  child: Text(
                                    'Family Talk',
                                    style: SafeGoogleFont (
                                      'Open Sans',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.3625*ffem/fem,
                                      letterSpacing: 0.1142857149*fem,
                                      color: Color(0xff101436),
                                    ),
                                  ),
                                ),
                                Text(
                                  // courseXyw (184:1630)
                                  '2 Notes',
                                  style: SafeGoogleFont (
                                    'Open Sans',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    letterSpacing: 0.1000000015*fem,
                                    color: Color(0xff101436),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // vectorSr1 (184:1631)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.96*fem),
                            width: 16.67*fem,
                            height: 27*fem,
                            child: Image.asset(
                              'assets/page-1/images/vector-ZzD.png',
                              width: 16.67*fem,
                              height: 27*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse197LRb (184:1634)
                    left: 217*fem,
                    top: 273*fem,
                    child: Align(
                      child: SizedBox(
                        width: 186*fem,
                        height: 186*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(93*fem),
                            color: Color(0xff8073ff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 0*fem),
                                blurRadius: 35*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group36700PPs (184:1635)
                    left: 271*fem,
                    top: 324*fem,
                    child: Container(
                      width: 65.44*fem,
                      height: 65.44*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(5.5*fem),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // rectangle73gds (184:1636)
                            left: 0*fem,
                            top: 27.7915039062*fem,
                            child: Align(
                              child: SizedBox(
                                width: 65.44*fem,
                                height: 9.86*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.5*fem),
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // rectangle74Yvy (184:1637)
                            left: 27.7915039062*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 9.86*fem,
                                height: 65.44*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.5*fem),
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle25T (184:1589)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 374*fem,
                        height: 436*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.only (
                              topLeft: Radius.circular(55*fem),
                              topRight: Radius.circular(55*fem),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 0*fem),
                                blurRadius: 40*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // coursecontent4nq (184:1590)
                    left: 58*fem,
                    top: 28*fem,
                    child: Align(
                      child: SizedBox(
                        width: 257*fem,
                        height: 36*fem,
                        child: Text(
                          'Choose Your Method',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.1714285761*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle7WD (184:1591)
                    left: 16*fem,
                    top: 291*fem,
                    child: Align(
                      child: SizedBox(
                        width: 343*fem,
                        height: 63*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(31*fem),
                              gradient: LinearGradient (
                                begin: Alignment(-2.212, 1.607),
                                end: Alignment(0.999, 1.607),
                                colors: <Color>[Color(0xffff8e5a), Color(0xffffc862)],
                                stops: <double>[0, 1],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x6effbe89),
                                  offset: Offset(0*fem, 6*fem),
                                  blurRadius: 5.5*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle4sNu (184:1592)
                    left: 23*fem,
                    top: 89*fem,
                    child: Align(
                      child: SizedBox(
                        width: 330*fem,
                        height: 84*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(20*fem),
                            color: Color(0xfff4f4f4),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle5Acu (184:1593)
                    left: 23*fem,
                    top: 89*fem,
                    child: Align(
                      child: SizedBox(
                        width: 330*fem,
                        height: 84*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                              color: Color(0xfff4f4f4),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle6qyw (184:1594)
                    left: 23*fem,
                    top: 190*fem,
                    child: Align(
                      child: SizedBox(
                        width: 330*fem,
                        height: 84*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                              border: Border.all(color: Color(0xff8073ff)),
                              color: Color(0xfff4f4f4),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x19000000),
                                  offset: Offset(0*fem, 0*fem),
                                  blurRadius: 2.5*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // buynow5dP (184:1595)
                    left: 112*fem,
                    top: 309*fem,
                    child: Align(
                      child: SizedBox(
                        width: 148*fem,
                        height: 30*fem,
                        child: Text(
                          'Start Listening',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.1428571492*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectanglecopy7ve1 (184:1596)
                    left: 301*fem,
                    top: 112*fem,
                    child: Align(
                      child: SizedBox(
                        width: 34*fem,
                        height: 34*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(5*fem),
                            color: Color(0xff8073ff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectanglecopy8CbX (184:1597)
                    left: 301*fem,
                    top: 215*fem,
                    child: Align(
                      child: SizedBox(
                        width: 34*fem,
                        height: 34*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(5*fem),
                            color: Color(0xff8073ff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // mins59X (184:1598)
                    left: 43*fem,
                    top: 123*fem,
                    child: Align(
                      child: SizedBox(
                        width: 236*fem,
                        height: 39*fem,
                        child: Text(
                          'Transform your documents or photos into notes with a quick scan.',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // customerperspectiveLbF (184:1599)
                    left: 42*fem,
                    top: 101*fem,
                    child: Align(
                      child: SizedBox(
                        width: 165*fem,
                        height: 24*fem,
                        child: Text(
                          'Upload a Document',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.1142857149*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // minsni9 (184:1600)
                    left: 43*fem,
                    top: 224*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'Easily turn your spoken words into text with our transcription service.',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // minsFrd (184:1601)
                    left: 157*fem,
                    top: 380*fem,
                    child: Align(
                      child: SizedBox(
                        width: 59*fem,
                        height: 21*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Text(
                            'Go Back',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5*ffem/fem,
                              letterSpacing: 0.1000000015*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // customerperspectiveWnZ (184:1602)
                    left: 42*fem,
                    top: 202*fem,
                    child: Align(
                      child: SizedBox(
                        width: 157*fem,
                        height: 24*fem,
                        child: Text(
                          'Listen and Capture',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.1142857149*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // iconmicrophonezBw (184:1603)
                    left: 312*fem,
                    top: 223*fem,
                    child: Align(
                      child: SizedBox(
                        width: 13.3*fem,
                        height: 17.78*fem,
                        child: Image.asset(
                          'assets/page-1/images/icon-microphone.png',
                          width: 13.3*fem,
                          height: 17.78*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // scan321cq (184:1605)
                    left: 305*fem,
                    top: 116*fem,
                    child: Align(
                      child: SizedBox(
                        width: 26*fem,
                        height: 26*fem,
                        child: Image.asset(
                          'assets/page-1/images/scan-3-2.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}