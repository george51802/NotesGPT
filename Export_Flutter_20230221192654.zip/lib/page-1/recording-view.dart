import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // recordingviewHQR (28:45)
        padding: EdgeInsets.fromLTRB(8*fem, 0*fem, 7*fem, 30*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0, -1),
            end: Alignment(0, 1),
            colors: <Color>[Color(0xff9a69ff), Color(0xff000000)],
            stops: <double>[0.083, 1],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarwithnotchsfTy7 (38:1664)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
              width: double.infinity,
              height: 44*fem,
              child: Stack(
                children: [
                  Positioned(
                    // notchLn1 (38:1665)
                    left: 78*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 219*fem,
                        height: 30*fem,
                        child: Image.asset(
                          'assets/page-1/images/notch-kgm.png',
                          width: 219*fem,
                          height: 30*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // timeczR (38:1666)
                    left: 32*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 26*fem,
                        height: 21*fem,
                        child: Text(
                          '9:41',
                          style: SafeGoogleFont (
                            'SF Pro Text',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.4*ffem/fem,
                            letterSpacing: -0.3199999928*fem,
                            color: Color(0xff020202),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // iosiconstatusbarSyT (38:1667)
                    left: -8*fem,
                    top: 5*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                      width: 1929*fem,
                      height: 26*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // autogroup5nkd741 (McufQcriRhVQCLb2ya5nkD)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                            width: 48.96*fem,
                            height: 16*fem,
                          ),
                          Container(
                            // iosiconsmallmobilesignalCbF (I38:1667;9:6)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                            width: 17*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-mobile-signal-aCm.png',
                              width: 17*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallwifiei9 (I38:1667;9:12)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                            width: 15.27*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-wifi-JZs.png',
                              width: 15.27*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallbatteryXG9 (I38:1667;9:17)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                            width: 24.33*fem,
                            height: 11.33*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-battery-s7K.png',
                              width: 24.33*fem,
                              height: 11.33*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // iosicon24threelinemenuPp9 (38:1697)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 305*fem, 10*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 40*fem,
                  height: 40*fem,
                  child: Image.asset(
                    'assets/page-1/images/ios-icon-24-three-line-menu-hTs.png',
                    width: 40*fem,
                    height: 40*fem,
                  ),
                ),
              ),
            ),
            Container(
              // autogroupm5hx26R (McuXUWk2rq2UfkrmMtM5hX)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 95*fem, 27*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroupettbXJ5 (McuXqfoSwPHsNcxdr6ETTB)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                    width: 31*fem,
                    height: 31*fem,
                    child: Image.asset(
                      'assets/page-1/images/auto-group-ettb.png',
                      width: 31*fem,
                      height: 31*fem,
                    ),
                  ),
                  Text(
                    // customerperspectiveBtR (138:2029)
                    'Listen and Capture',
                    style: SafeGoogleFont (
                      'Open Sans',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w600,
                      height: 1.3625*ffem/fem,
                      letterSpacing: 0.1142857149*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupgmhf4SR (McuY1fWnzT7naAPndPGMHf)
              margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 19*fem, 28*fem),
              padding: EdgeInsets.fromLTRB(20*fem, 10*fem, 5*fem, 13*fem),
              width: double.infinity,
              height: 361*fem,
              decoration: BoxDecoration (
                color: Color(0xfff4f4f4),
                borderRadius: BorderRadius.circular(20*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 0*fem),
                    blurRadius: 4*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupbkko4Kw (McuYLjoLyY17Shs12zBkKo)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // minsxgD (138:2099)
                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 7*fem),
                          constraints: BoxConstraints (
                            maxWidth: 287*fem,
                          ),
                          child: Text(
                            'of our interview, and I want to get through\nthese as quickly as possible because I know you have somewhere to be.',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1000000015*fem,
                              color: Color(0xff101436),
                            ),
                          ),
                        ),
                        Container(
                          // customerperspective1eV (138:2097)
                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 3*fem),
                          child: Text(
                            '00:32',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1142857149*fem,
                              color: Color(0xff101436),
                            ),
                          ),
                        ),
                        Container(
                          // minsh1X (138:2098)
                          constraints: BoxConstraints (
                            maxWidth: 297*fem,
                          ),
                          child: Text(
                            'Borem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus urna at turpis condimentum lobortis. Ut commodo efficitur neque. Ut diam quam, semper iaculis condimentum ac, vestibulum eu nisl. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.Class aptent taciti sociosqu ad litora torquent per conubia nostra, per incas',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1000000015*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // rectangle55BBb (138:2096)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                    width: 2*fem,
                    height: 238*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(20*fem),
                      color: Color(0xffc8c8c8),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouphzo3UgV (McuYdp9E9c845LePHXhZo3)
              margin: EdgeInsets.fromLTRB(123*fem, 0*fem, 128*fem, 10*fem),
              width: double.infinity,
              height: 39*fem,
              decoration: BoxDecoration (
                color: Color(0xffeaeaea),
                borderRadius: BorderRadius.circular(20*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 0*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  '00:01:50',
                  style: SafeGoogleFont (
                    'Source Sans Pro',
                    fontSize: 24*ffem,
                    fontWeight: FontWeight.w600,
                    height: 1.2575*ffem/fem,
                    letterSpacing: 0.1714285761*fem,
                    color: Color(0xff101436),
                  ),
                ),
              ),
            ),
            Container(
              // minsH89 (138:2085)
              margin: EdgeInsets.fromLTRB(43*fem, 0*fem, 0*fem, 1*fem),
              child: Text(
                '01:25',
                style: SafeGoogleFont (
                  'Open Sans',
                  fontSize: 10*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3625*ffem/fem,
                  letterSpacing: 0.1000000015*fem,
                  color: Color(0xff101436),
                ),
              ),
            ),
            Container(
              // autogroupdzmsAhj (McuZEYeMUxfiVVpwFRdzms)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 3*fem, 1*fem),
              width: double.infinity,
              height: 92*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupdkezrKf (Mcubayj2JcPtMkCMQgdkEZ)
                    padding: EdgeInsets.fromLTRB(0*fem, 14*fem, 3*fem, 6*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle33Wf7 (138:2058)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 28*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle341Ly (138:2059)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 18*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle53iFP (138:2078)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 12*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle52ba5 (138:2077)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 18*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle54JDb (138:2079)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 12*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle51og9 (138:2076)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 18*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle50K8h (138:2075)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 28*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle49EFf (138:2074)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 34*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle48YXF (138:2073)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 46*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle35rH3 (138:2060)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 58*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle36MzV (138:2061)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 72*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle37Fpy (138:2062)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 64*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle38wxh (138:2063)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 38*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle39TAM (138:2064)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 26*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle40Ljw (138:2065)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 12*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle41eEq (138:2066)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 10*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle42MQ9 (138:2067)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 12*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle434JZ (138:2068)
                          width: 5*fem,
                          height: 16*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupewqmBe5 (McuaMM7iFyJp6hFmUkEWQm)
                    width: 13*fem,
                    height: 92*fem,
                    child: Image.asset(
                      'assets/page-1/images/auto-group-ewqm.png',
                      width: 13*fem,
                      height: 92*fem,
                    ),
                  ),
                  Container(
                    // autogroupy9vugaq (McucDo11jSKccE1ZTBY9vu)
                    padding: EdgeInsets.fromLTRB(3*fem, 21*fem, 4*fem, 13*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle47yZw (138:2072)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 52*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffffae60),
                          ),
                        ),
                        Container(
                          // rectangle45N5 (138:2033)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 58*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffffae60),
                          ),
                        ),
                        Container(
                          // rectangle5KXK (138:2034)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 46*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffffae60),
                          ),
                        ),
                        Container(
                          // rectangle6x4V (138:2035)
                          width: 5*fem,
                          height: 34*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffffae60),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjj2dDm7 (McuaeWHniW3SKjyyeqJj2d)
                    width: 14*fem,
                    height: 92*fem,
                    child: Image.asset(
                      'assets/page-1/images/auto-group-jj2d.png',
                      width: 14*fem,
                      height: 92*fem,
                    ),
                  ),
                  Container(
                    // autogrouphzzdg8u (McucXCfg3LuHcWaFPuHZzd)
                    padding: EdgeInsets.fromLTRB(3*fem, 14*fem, 0*fem, 6*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle9X9X (138:2056)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 12*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle11cwf (138:2055)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 18*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle12KbB (138:2057)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 12*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle17omF (138:2054)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 18*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle16WQm (138:2053)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 28*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle151MX (138:2052)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 34*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle14uho (138:2051)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 5*fem,
                          height: 46*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle13p45 (138:2038)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 58*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle18i9T (138:2039)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 72*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle19DM7 (138:2040)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 64*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle20Kf3 (138:2041)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 38*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle21qNV (138:2042)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 26*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle22kVT (138:2043)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 12*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle235Gq (138:2044)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 10*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle24PYR (138:2045)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 12*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle25W7F (138:2046)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                          width: 5*fem,
                          height: 16*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // autogroupkkykcAH (McuavAWN4mhmsMhKD8KkyK)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 2*fem),
                          width: 5*fem,
                          height: 26*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-kkyk.png',
                            width: 5*fem,
                            height: 26*fem,
                          ),
                        ),
                        Container(
                          // rectangle28tNh (138:2049)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 2*fem),
                          width: 5*fem,
                          height: 38*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // rectangle29PqF (138:2050)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                          width: 5*fem,
                          height: 52*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // mins6Um (138:2084)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 59*fem, 22*fem),
              child: Text(
                '01:20',
                style: SafeGoogleFont (
                  'Open Sans',
                  fontSize: 10*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3625*ffem/fem,
                  letterSpacing: 0.1000000015*fem,
                  color: Color(0xff101436),
                ),
              ),
            ),
            Container(
              // autogroupxbthxWy (McueQyr649m1ceTG93Xbth)
              margin: EdgeInsets.fromLTRB(73*fem, 0*fem, 74*fem, 0*fem),
              width: double.infinity,
              height: 74*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupdqhfeeh (McuegtZFFoGPwW15TyDqHF)
                    margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 34*fem, 16*fem),
                    padding: EdgeInsets.fromLTRB(14*fem, 15*fem, 14*fem, 13*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(21*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x1e000000),
                          offset: Offset(0*fem, 3*fem),
                          blurRadius: 5*fem,
                        ),
                      ],
                    ),
                    child: Center(
                      // close1Utd (138:2094)
                      child: SizedBox(
                        width: 14*fem,
                        height: 14*fem,
                        child: Image.asset(
                          'assets/page-1/images/close-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupmny5C3w (McuendtfqTiVszE6AWmNY5)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(30*fem, 28*fem, 29*fem, 26*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xffffffff)),
                      borderRadius: BorderRadius.circular(37*fem),
                      gradient: LinearGradient (
                        begin: Alignment(0, -1),
                        end: Alignment(0, 1),
                        colors: <Color>[Color(0xffffa75f), Color(0xffffc663)],
                        stops: <double>[0, 1],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x1e000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2.5*fem,
                        ),
                      ],
                    ),
                    child: Center(
                      // group5xxD (138:2090)
                      child: SizedBox(
                        width: 15*fem,
                        height: 20*fem,
                        child: Image.asset(
                          'assets/page-1/images/group-5.png',
                          width: 15*fem,
                          height: 20*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupgtwrfLq (McuevTzxWbYfeo5kwfGtWR)
                    margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 16*fem),
                    padding: EdgeInsets.fromLTRB(13*fem, 14*fem, 13*fem, 12*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(21*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x1e000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 5*fem,
                        ),
                      ],
                    ),
                    child: Center(
                      // check1KRP (138:2093)
                      child: SizedBox(
                        width: 16*fem,
                        height: 16*fem,
                        child: Image.asset(
                          'assets/page-1/images/check-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}