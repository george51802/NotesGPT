import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 343;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // rectangleaWH (184:1222)
        width: double.infinity,
        height: 63*fem,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.circular(31*fem),
          gradient: LinearGradient (
            begin: Alignment(-2.212, 1.607),
            end: Alignment(0.999, 1.607),
            colors: <Color>[Color(0xffc05aff), Color(0xff627bff)],
            stops: <double>[0, 1],
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0x6effbe89),
              offset: Offset(0*fem, 6*fem),
              blurRadius: 5.5*fem,
            ),
          ],
        ),
      ),
          );
  }
}