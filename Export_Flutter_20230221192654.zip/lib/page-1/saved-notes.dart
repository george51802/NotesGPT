import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // savednotesLgD (94:1687)
        padding: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarwithnotchsf1GZ (94:1694)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 33*fem),
              width: 375*fem,
              height: 44*fem,
              child: Stack(
                children: [
                  Positioned(
                    // notchGiH (I94:1694;38:1665)
                    left: 78*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 219*fem,
                        height: 30*fem,
                        child: Image.asset(
                          'assets/page-1/images/notch-KRw.png',
                          width: 219*fem,
                          height: 30*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // timekNZ (I94:1694;38:1666)
                    left: 32*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 26*fem,
                        height: 21*fem,
                        child: Text(
                          '9:41',
                          style: SafeGoogleFont (
                            'SF Pro Text',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.4*ffem/fem,
                            letterSpacing: -0.3199999928*fem,
                            color: Color(0xff020202),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // iosiconstatusbarABP (I94:1694;38:1667)
                    left: -8*fem,
                    top: 5*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                      width: 1929*fem,
                      height: 26*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // autogroupbvuqzw7 (McujnKuJoTSjTsupxwbVUq)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                            width: 48.96*fem,
                            height: 16*fem,
                          ),
                          Container(
                            // iosiconsmallmobilesignalJS1 (I94:1694;38:1667;9:6)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                            width: 17*fem,
                            height: 10.67*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-mobile-signal-e3P.png',
                              width: 17*fem,
                              height: 10.67*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallwifia8d (I94:1694;38:1667;9:12)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                            width: 15.27*fem,
                            height: 10.97*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-wifi.png',
                              width: 15.27*fem,
                              height: 10.97*fem,
                            ),
                          ),
                          Container(
                            // iosiconsmallbattery32D (I94:1694;38:1667;9:17)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                            width: 24.33*fem,
                            height: 11.33*fem,
                            child: Image.asset(
                              'assets/page-1/images/ios-icon-small-battery-21K.png',
                              width: 24.33*fem,
                              height: 11.33*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup2bqxu4R (McujJWNL2BxjHzBrdD2BqX)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 146*fem, 34*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // iosicon24threelinemenuoQh (184:1487)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/page-1/images/ios-icon-24-three-line-menu.png',
                          width: 40*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Text(
                    // noteslibraryRS5 (184:1493)
                    'Notes Library',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.5*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group3669685b (184:1458)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 34*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(38.23*fem, 17.78*fem, 25.33*fem, 11.82*fem),
              width: double.infinity,
              height: 73*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff8073ff)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(7*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 8*fem),
                    blurRadius: 20*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group36695JeH (184:1457)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 156.77*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // codingDFT (184:1455)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.4*fem),
                          child: Text(
                            'Class Notes',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1142857149*fem,
                              color: Color(0xff101436),
                            ),
                          ),
                        ),
                        Text(
                          // courseHFK (184:1456)
                          '12 Notes',
                          style: SafeGoogleFont (
                            'Open Sans',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // vectorydw (184:1460)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.96*fem),
                    width: 16.67*fem,
                    height: 27*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-ZXT.png',
                      width: 16.67*fem,
                      height: 27*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group366974vH (184:1462)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 34*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(38.23*fem, 17.78*fem, 25.33*fem, 11.82*fem),
              width: double.infinity,
              height: 73*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff8073ff)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(7*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 8*fem),
                    blurRadius: 20*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group36695H2M (184:1464)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 132.77*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // codingnE1 (184:1465)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.4*fem),
                          child: Text(
                            'Meeting Notes',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1142857149*fem,
                              color: Color(0xff101436),
                            ),
                          ),
                        ),
                        Text(
                          // courseTb3 (184:1466)
                          '12 Notes',
                          style: SafeGoogleFont (
                            'Open Sans',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // vectorNi1 (184:1467)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.96*fem),
                    width: 16.67*fem,
                    height: 27*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-f6M.png',
                      width: 16.67*fem,
                      height: 27*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group36698UFF (184:1468)
              margin: EdgeInsets.fromLTRB(19*fem, 0*fem, 35*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(38.23*fem, 17.78*fem, 25.33*fem, 11.82*fem),
              width: double.infinity,
              height: 73*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff8073ff)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(7*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 8*fem),
                    blurRadius: 20*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group36695HyP (184:1470)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 188.77*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // coding1eV (184:1471)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.4*fem),
                          child: Text(
                            'EGR102',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1142857149*fem,
                              color: Color(0xff101436),
                            ),
                          ),
                        ),
                        Text(
                          // course6R3 (184:1472)
                          '4 Notes',
                          style: SafeGoogleFont (
                            'Open Sans',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // vectornYm (184:1473)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.96*fem),
                    width: 16.67*fem,
                    height: 27*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-zSq.png',
                      width: 16.67*fem,
                      height: 27*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group36699Gyj (184:1474)
              margin: EdgeInsets.fromLTRB(19*fem, 0*fem, 35*fem, 200*fem),
              padding: EdgeInsets.fromLTRB(38.23*fem, 17.78*fem, 25.33*fem, 11.82*fem),
              width: double.infinity,
              height: 73*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff8073ff)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(7*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0c000000),
                    offset: Offset(0*fem, 8*fem),
                    blurRadius: 20*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group36695sTj (184:1476)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 159.77*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // codingBjK (184:1477)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.4*fem),
                          child: Text(
                            'Family Talk',
                            style: SafeGoogleFont (
                              'Open Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              letterSpacing: 0.1142857149*fem,
                              color: Color(0xff101436),
                            ),
                          ),
                        ),
                        Text(
                          // courseUTX (184:1478)
                          '2 Notes',
                          style: SafeGoogleFont (
                            'Open Sans',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            letterSpacing: 0.1000000015*fem,
                            color: Color(0xff101436),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // vectorb2M (184:1479)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.96*fem),
                    width: 16.67*fem,
                    height: 27*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-cb7.png',
                      width: 16.67*fem,
                      height: 27*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupj7dp5y7 (McujS19qZVLAh9GDiBJ7DP)
              margin: EdgeInsets.fromLTRB(217*fem, 0*fem, 0*fem, 0*fem),
              padding: EdgeInsets.fromLTRB(54*fem, 51*fem, 66.56*fem, 69.56*fem),
              width: 186*fem,
              height: 186*fem,
              decoration: BoxDecoration (
                color: Color(0xff8073ff),
                borderRadius: BorderRadius.circular(93*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 0*fem),
                    blurRadius: 35*fem,
                  ),
                ],
              ),
              child: Center(
                // group36700K6m (184:1578)
                child: SizedBox(
                  width: 65.44*fem,
                  height: 65.44*fem,
                  child: Image.asset(
                    'assets/page-1/images/group-36700.png',
                    width: 65.44*fem,
                    height: 65.44*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}