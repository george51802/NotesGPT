import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signupU3F (61:2594)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarmodalstacksfxj7 (61:2606)
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff020202),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouphfkhfdX (McvLX5XE1NxCQJJGdWhfkh)
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupzxxm38H (McvL3BA3werWdzdUNEZxxm)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 7*fem),
                          width: 1929*fem,
                          height: 36*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // notchugH (I61:2606;33:1673)
                                left: 85*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 219*fem,
                                    height: 30*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/notch-Tyw.png',
                                      width: 219*fem,
                                      height: 30*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // timeb3K (I61:2606;33:1674)
                                left: 32*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 26*fem,
                                    height: 21*fem,
                                    child: Text(
                                      '9:41',
                                      style: SafeGoogleFont (
                                        'SF Pro Text',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.4*ffem/fem,
                                        letterSpacing: -0.3199999928*fem,
                                        color: Color(0xfffafafa),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // iosiconstatusbarEMB (I61:2606;33:1675)
                                left: 0*fem,
                                top: 5*fem,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                                  width: 1929*fem,
                                  height: 26*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xff020202),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Container(
                                        // autogroupr1w3suw (McvLHAkjckDCKMSHTeR1w3)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                                        width: 48.96*fem,
                                        height: 16*fem,
                                      ),
                                      Container(
                                        // iosiconsmallmobilesignalmEd (I61:2606;33:1675;9:6)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                                        width: 17*fem,
                                        height: 10.67*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ios-icon-small-mobile-signal-B8R.png',
                                          width: 17*fem,
                                          height: 10.67*fem,
                                        ),
                                      ),
                                      Container(
                                        // iosiconsmallwifipyb (I61:2606;33:1675;9:12)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                                        width: 15.27*fem,
                                        height: 10.97*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ios-icon-small-wifi-kQm.png',
                                          width: 15.27*fem,
                                          height: 10.97*fem,
                                        ),
                                      ),
                                      Container(
                                        // iosiconsmallbatteryv13 (I61:2606;33:1675;9:17)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                                        width: 24.33*fem,
                                        height: 11.33*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ios-icon-small-battery-eLD.png',
                                          width: 24.33*fem,
                                          height: 11.33*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // secondpagePvD (I61:2606;33:1677)
                          margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                          width: double.infinity,
                          height: 10*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff9e9e9e),
                            borderRadius: BorderRadius.only (
                              topLeft: Radius.circular(10*fem),
                              topRight: Radius.circular(10*fem),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // firstpage4mT (I61:2606;33:1676)
                    width: double.infinity,
                    height: 14*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(10*fem),
                        topRight: Radius.circular(10*fem),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupuerrAJh (McvJwnozzSg27pGgqAUErR)
              padding: EdgeInsets.fromLTRB(19*fem, 162*fem, 0*fem, 19*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // notesgpt0114Q5 (138:1880)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28*fem, 18*fem),
                    width: 303*fem,
                    height: 65*fem,
                    child: Image.asset(
                      'assets/page-1/images/notesgpt-01-1-mJd.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // createaccount9wK (138:1898)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 135*fem, 26*fem),
                    child: Text(
                      'Create account',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 30*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.3*ffem/fem,
                        letterSpacing: -0.3*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupe5wmRdw (McvHG67o8B2H9YTUwvE5WM)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 22*fem),
                    width: 353*fem,
                    height: 278*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // input7mf (138:1893)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            width: 353*fem,
                            height: 102*fem,
                            child: Container(
                              // autogroup58udqBs (McvHW5iUoGNxpuGJ3L58Ud)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 46*fem),
                              width: double.infinity,
                              height: 56*fem,
                              child: Container(
                                // inputfieldkZj (I138:1893;18:227)
                                padding: EdgeInsets.fromLTRB(16*fem, 18*fem, 16*fem, 18*fem),
                                width: double.infinity,
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xffd8dadc)),
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(10*fem),
                                ),
                                child: Text(
                                  'Email address',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.25*ffem/fem,
                                    color: Color(0x7f000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // inputbaM (138:1894)
                          left: 0*fem,
                          top: 70*fem,
                          child: Container(
                            width: 353*fem,
                            height: 102*fem,
                            child: Container(
                              // autogroup7kp172u (McvHqKfRMGVetGdAJ27Kp1)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 46*fem),
                              width: double.infinity,
                              height: 56*fem,
                              child: Container(
                                // inputfieldDbj (I138:1894;18:227)
                                padding: EdgeInsets.fromLTRB(16*fem, 18*fem, 18*fem, 18*fem),
                                width: double.infinity,
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xffd8dadc)),
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(10*fem),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // textVZF (I138:1894;16:184)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 228*fem, 0*fem),
                                      child: Text(
                                        'Password',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.25*ffem/fem,
                                          color: Color(0x7f000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // iconaKo (I138:1894;20:223)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                      width: 17*fem,
                                      height: 15*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/icon-CCM.png',
                                        width: 17*fem,
                                        height: 15*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // inputg7w (138:1895)
                          left: 0*fem,
                          top: 140*fem,
                          child: Container(
                            width: 353*fem,
                            height: 102*fem,
                            child: Container(
                              // autogroupbywfaj7 (McvJ7eXYyD5TBBu7EfbYwf)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 46*fem),
                              width: double.infinity,
                              height: 56*fem,
                              child: Container(
                                // inputfieldJ9K (I138:1895;18:227)
                                padding: EdgeInsets.fromLTRB(16*fem, 18*fem, 18*fem, 18*fem),
                                width: double.infinity,
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xffd8dadc)),
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.circular(10*fem),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // textNey (I138:1895;16:184)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 164*fem, 0*fem),
                                      child: Text(
                                        'Confirm password',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.25*ffem/fem,
                                          color: Color(0x7f000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // icons5w (I138:1895;20:223)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                      width: 17*fem,
                                      height: 15*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/icon.png',
                                        width: 17*fem,
                                        height: 15*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // buttonprimaryZUZ (138:1896)
                          left: 0*fem,
                          top: 222*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 353*fem,
                              height: 56*fem,
                              decoration: BoxDecoration (
                                color: Color(0xff000000),
                                borderRadius: BorderRadius.circular(10*fem),
                              ),
                              child: Center(
                                child: Center(
                                  child: Text(
                                    'Create account',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.25*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupaz2yYLV (McvJPPaKbwMUKDZGiWAz2y)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 22*fem),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // line21FVo (138:2006)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          width: 122*fem,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd8dadc),
                          ),
                        ),
                        SizedBox(
                          width: 10*fem,
                        ),
                        Text(
                          // orloginwith8Zb (138:2004)
                          'Or Login with',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.25*ffem/fem,
                            color: Color(0xb2000000),
                          ),
                        ),
                        SizedBox(
                          width: 10*fem,
                        ),
                        Container(
                          // line20dmF (138:2005)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          width: 122*fem,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd8dadc),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupxgrbx2q (McvJZ8o5odLLjX9wjAXgRb)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 36*fem),
                    width: 387*fem,
                    height: 56*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // buttonwithcenterediconre1 (138:2007)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(44*fem, 18*fem, 0*fem, 18*fem),
                            width: 142*fem,
                            height: 56*fem,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffd8dadc)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Container(
                              // frame36695KXb (I138:2007;31:495)
                              padding: EdgeInsets.fromLTRB(6*fem, 1*fem, 6*fem, 1*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Align(
                                // socialiconfacebooke45 (I138:2007;31:489)
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  width: 8.96*fem,
                                  height: 18*fem,
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 77.04*fem, 0*fem),
                                    child: Image.asset(
                                      'assets/page-1/images/social-icon-facebook-JS1.png',
                                      width: 8.96*fem,
                                      height: 18*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // buttonwithcenteredicon6wf (138:2008)
                          left: 123*fem,
                          top: 0*fem,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(44*fem, 18*fem, 0*fem, 18*fem),
                            width: 142*fem,
                            height: 56*fem,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffd8dadc)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Container(
                              // frame36695N8V (I138:2008;31:495)
                              padding: EdgeInsets.fromLTRB(1*fem, 0*fem, 1*fem, 0*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Align(
                                // socialicongoogleJ29 (I138:2008;31:489)
                                alignment: Alignment.topLeft,
                                child: SizedBox(
                                  width: 18.17*fem,
                                  height: 19*fem,
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 77.83*fem, 1*fem),
                                    child: Image.asset(
                                      'assets/page-1/images/social-icon-google.png',
                                      width: 18.17*fem,
                                      height: 19*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // buttonwithcenterediconMFK (138:2009)
                          left: 245*fem,
                          top: 0*fem,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(44*fem, 18*fem, 0*fem, 18*fem),
                            width: 142*fem,
                            height: 56*fem,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffd8dadc)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Container(
                              // frame36695QzH (I138:2009;31:495)
                              padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 2*fem, 0*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Align(
                                // socialiconappleYKo (I138:2009;31:489)
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  width: 16.53*fem,
                                  height: 19.93*fem,
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 77.47*fem, 0.07*fem),
                                    child: Image.asset(
                                      'assets/page-1/images/social-icon-apple.png',
                                      width: 16.53*fem,
                                      height: 19.93*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Center(
                    // alreadyhaveanaccountsignupbos (138:1897)
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 14*fem, 0*fem),
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.25*ffem/fem,
                            color: Color(0xff000000),
                          ),
                          children: [
                            TextSpan(
                              text: 'Already have an account. ',
                            ),
                            TextSpan(
                              text: 'Sign up',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.25*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}