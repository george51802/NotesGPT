import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // subsriptionview21T (85:3853)
        width: double.infinity,
        height: 844*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // iosstatusbar6n1 (85:3862)
              left: 8*fem,
              top: 0*fem,
              child: Container(
                width: 375*fem,
                height: 44*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // timeax5 (I85:3862;38:1633)
                      left: 32*fem,
                      top: 13*fem,
                      child: Align(
                        child: SizedBox(
                          width: 26*fem,
                          height: 21*fem,
                          child: Text(
                            '9:41',
                            style: SafeGoogleFont (
                              'SF Pro Text',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.4*ffem/fem,
                              letterSpacing: -0.3199999928*fem,
                              color: Color(0xff020202),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // iosiconstatusbarQAR (I85:3862;38:1634)
                      left: -8*fem,
                      top: 5*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                        width: 1929*fem,
                        height: 26*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              // autogroupdyyh3z5 (McuVNpjoGQC8paobbwDyYh)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                              width: 48.96*fem,
                              height: 16*fem,
                            ),
                            Container(
                              // iosiconsmallmobilesignalxbF (I85:3862;38:1634;9:6)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                              width: 17*fem,
                              height: 10.67*fem,
                              child: Image.asset(
                                'assets/page-1/images/ios-icon-small-mobile-signal-HZF.png',
                                width: 17*fem,
                                height: 10.67*fem,
                              ),
                            ),
                            Container(
                              // iosiconsmallwifiQi9 (I85:3862;38:1634;9:12)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                              width: 15.27*fem,
                              height: 10.97*fem,
                              child: Image.asset(
                                'assets/page-1/images/ios-icon-small-wifi-qY1.png',
                                width: 15.27*fem,
                                height: 10.97*fem,
                              ),
                            ),
                            Container(
                              // iosiconsmallbatterygQm (I85:3862;38:1634;9:17)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                              width: 24.33*fem,
                              height: 11.33*fem,
                              child: Image.asset(
                                'assets/page-1/images/ios-icon-small-battery.png',
                                width: 24.33*fem,
                                height: 11.33*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle29vK7 (184:1302)
              left: 0*fem,
              top: 62*fem,
              child: Align(
                child: SizedBox(
                  width: 722.58*fem,
                  height: 915.98*fem,
                  child: Image.asset(
                    'assets/page-1/images/rectangle-29.png',
                    width: 722.58*fem,
                    height: 915.98*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // robot1PyP (184:1294)
              left: 5*fem,
              top: 29*fem,
              child: Align(
                child: SizedBox(
                  width: 308*fem,
                  height: 308*fem,
                  child: Image.asset(
                    'assets/page-1/images/robot-1-Pkh.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // cardpricing1677 (184:1253)
              left: 64*fem,
              top: 219*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(40.5*fem, 89*fem, 40.5*fem, 33*fem),
                width: 270*fem,
                height: 420*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff000000)),
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(27*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Center(
                      // title7H7 (I184:1253;0:98)
                      child: Container(
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                        child: Text(
                          'Upgrade your Plan',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                    Center(
                      // subtitlen8M (I184:1253;0:99)
                      child: Container(
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 199*fem),
                        child: Text(
                          'Join for as little as \$4.99/month',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 2*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // buttonsecondaryeRT (I184:1253;0:103)
                      margin: EdgeInsets.fromLTRB(14.5*fem, 0*fem, 14.5*fem, 0*fem),
                      width: double.infinity,
                      height: 40*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xff000000)),
                        borderRadius: BorderRadius.circular(5*fem),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Upgrade',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // textrnR (184:1301)
              left: 101*fem,
              top: 407*fem,
              child: Align(
                child: SizedBox(
                  width: 175*fem,
                  height: 78*fem,
                  child: Text(
                    'More processing power\nTranscribe over 10 minute limit\nGenerate more than 1000 words',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 11*ffem,
                      fontWeight: FontWeight.w300,
                      height: 2.3636363636*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group36694Kg1 (184:1299)
              left: 256*fem,
              top: 252*fem,
              child: Container(
                width: 18*fem,
                height: 18*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(2*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x0c000000),
                      offset: Offset(-2*fem, 2*fem),
                      blurRadius: 2.5*fem,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // rectangle68NPP (184:1297)
                      left: 8*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 2*fem,
                          height: 18*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(2*fem),
                              color: Color(0xfff69351),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle69eLu (184:1298)
                      left: 0*fem,
                      top: 8*fem,
                      child: Align(
                        child: SizedBox(
                          width: 18*fem,
                          height: 2*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(2*fem),
                              color: Color(0xfff69351),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // crown1Khw (184:1293)
              left: 125*fem,
              top: 28*fem,
              child: Align(
                child: SizedBox(
                  width: 68*fem,
                  height: 68*fem,
                  child: Image.asset(
                    'assets/page-1/images/crown-1.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // notesgpt011peh (184:1295)
              left: 118*fem,
              top: 250*fem,
              child: Align(
                child: SizedBox(
                  width: 153*fem,
                  height: 33*fem,
                  child: Image.asset(
                    'assets/page-1/images/notesgpt-01-1-HWu.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // group10uw3 (98:1683)
              left: 121*fem,
              top: 764*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 156*fem,
                  height: 48*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff000000)),
                    color: Color(0xffffffff),
                    borderRadius: BorderRadius.circular(20*fem),
                  ),
                  child: Center(
                    child: Text(
                      'Return',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.5*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}