import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // welcomeQHK (85:2595)
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(-1, -0.031),
            end: Alignment(1.774, -0.658),
            colors: <Color>[Color(0xff9b69ff), Color(0xff657cff)],
            stops: <double>[0, 1],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarmodalstacksfRiD (85:2598)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff020202),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroups9evKHo (McvRFcJTKriC13wdQus9eV)
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupcn1kFBT (McvQZTngYgBA24KNSecn1K)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 7*fem),
                          width: 1929*fem,
                          height: 36*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // notchk8D (I85:2598;33:1673)
                                left: 85*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 219*fem,
                                    height: 30*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/notch-dcy.png',
                                      width: 219*fem,
                                      height: 30*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // timepds (I85:2598;33:1674)
                                left: 32*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 26*fem,
                                    height: 21*fem,
                                    child: Text(
                                      '9:41',
                                      style: SafeGoogleFont (
                                        'SF Pro Text',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.4*ffem/fem,
                                        letterSpacing: -0.3199999928*fem,
                                        color: Color(0xfffafafa),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // iosiconstatusbarFjB (I85:2598;33:1675)
                                left: 0*fem,
                                top: 5*fem,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(20.04*fem, 0*fem, 0*fem, 0*fem),
                                  width: 1929*fem,
                                  height: 26*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xff020202),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Container(
                                        // autogroupj1ufi6y (McvQpYBtujXiQnQvY8j1uf)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1796*fem, 10*fem),
                                        width: 48.96*fem,
                                        height: 16*fem,
                                      ),
                                      Container(
                                        // iosiconsmallmobilesignal1bs (I85:2598;33:1675;9:6)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.35*fem, 2.33*fem),
                                        width: 17*fem,
                                        height: 10.67*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ios-icon-small-mobile-signal-4i1.png',
                                          width: 17*fem,
                                          height: 10.67*fem,
                                        ),
                                      ),
                                      Container(
                                        // iosiconsmallwifiUEZ (I85:2598;33:1675;9:12)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.38*fem, 2.03*fem),
                                        width: 15.27*fem,
                                        height: 10.97*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ios-icon-small-wifi-Egm.png',
                                          width: 15.27*fem,
                                          height: 10.97*fem,
                                        ),
                                      ),
                                      Container(
                                        // iosiconsmallbattery9Lh (I85:2598;33:1675;9:17)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.67*fem),
                                        width: 24.33*fem,
                                        height: 11.33*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ios-icon-small-battery-uA5.png',
                                          width: 24.33*fem,
                                          height: 11.33*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // secondpagephj (I85:2598;33:1677)
                          margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                          width: double.infinity,
                          height: 10*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff9e9e9e),
                            borderRadius: BorderRadius.only (
                              topLeft: Radius.circular(10*fem),
                              topRight: Radius.circular(10*fem),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // firstpage6v9 (I85:2598;33:1676)
                    width: double.infinity,
                    height: 14*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(10*fem),
                        topRight: Radius.circular(10*fem),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcbbj1XK (McvNFrxdNdNCKr63ftcbbj)
              width: double.infinity,
              height: 916.14*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle29v8V (131:1683)
                    left: 0*fem,
                    top: 0.1612548828*fem,
                    child: Align(
                      child: SizedBox(
                        width: 722.58*fem,
                        height: 915.98*fem,
                        child: Image.asset(
                          'assets/page-1/images/rectangle-29-ciy.png',
                          width: 722.58*fem,
                          height: 915.98*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // howitworksayj (85:2625)
                    left: 69.5*fem,
                    top: 181*fem,
                    child: Align(
                      child: SizedBox(
                        width: 250*fem,
                        height: 86*fem,
                        child: Text(
                          'How it works',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 40*ffem,
                            fontWeight: FontWeight.w600,
                            height: 2.1375*ffem/fem,
                            letterSpacing: -0.4*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group83cR (85:2628)
                    left: 29*fem,
                    top: 663*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 333*fem,
                        height: 56*fem,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xff000000),
                          borderRadius: BorderRadius.circular(10*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Get Started',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group21dKj (131:1746)
                    left: 51*fem,
                    top: 264*fem,
                    child: Container(
                      width: 284*fem,
                      height: 347*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupvqp57Vo (McvNZMTUxzZYvYbZY9vQp5)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 19*fem),
                            width: double.infinity,
                            height: 70*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group17Cn9 (131:1742)
                                  margin: EdgeInsets.fromLTRB(0*fem, 20*fem, 17*fem, 20*fem),
                                  width: 30*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(15*fem),
                                    gradient: LinearGradient (
                                      begin: Alignment(-1, 0),
                                      end: Alignment(1, -0),
                                      colors: <Color>[Color(0xff946cff), Color(0xff7079ff)],
                                      stops: <double>[0, 1],
                                    ),
                                  ),
                                  child: Center(
                                    child: Center(
                                      child: Text(
                                        '1',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Open Sans',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group14ygR (131:1735)
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // startrecordingvLm (131:1716)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                        child: Text(
                                          'Start Recording',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // minsofT (131:1718)
                                        constraints: BoxConstraints (
                                          maxWidth: 231*fem,
                                        ),
                                        child: Text(
                                          'Press the Start Listening button to begin transcribing audio.',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 15*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupztxttgu (McvNomD94NzeZy8WFHZTXT)
                            width: double.infinity,
                            height: 70*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group18zzq (131:1743)
                                  margin: EdgeInsets.fromLTRB(0*fem, 19*fem, 17*fem, 21*fem),
                                  width: 30*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(15*fem),
                                    gradient: LinearGradient (
                                      begin: Alignment(-1, 0),
                                      end: Alignment(1, -0),
                                      colors: <Color>[Color(0xff946cff), Color(0xff7079ff)],
                                      stops: <double>[0, 1],
                                    ),
                                  ),
                                  child: Center(
                                    child: Center(
                                      child: Text(
                                        '2',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Open Sans',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group13ybs (131:1734)
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // chooseyourcontenthnm (131:1721)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
                                        child: Text(
                                          'Choose your content',
                                          style: SafeGoogleFont (
                                            'Open Sans',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.3625*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // minsBhw (131:1722)
                                        constraints: BoxConstraints (
                                          maxWidth: 237*fem,
                                        ),
                                        child: Text(
                                          'Use our transcription service or provide us with your content.',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 15*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupghuo5YR (McvPQAPVFu5acUXkX1GHuo)
                            padding: EdgeInsets.fromLTRB(0*fem, 24*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // autogroupw9qhPZ7 (McvNzLjr6f8LvQBSVPW9QH)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19*fem, 24*fem),
                                  width: double.infinity,
                                  height: 70*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // group19h41 (131:1744)
                                        margin: EdgeInsets.fromLTRB(0*fem, 20*fem, 17*fem, 20*fem),
                                        width: 30*fem,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(15*fem),
                                          gradient: LinearGradient (
                                            begin: Alignment(-1, 0),
                                            end: Alignment(1, -0),
                                            colors: <Color>[Color(0xff946cff), Color(0xff7079ff)],
                                            stops: <double>[0, 1],
                                          ),
                                        ),
                                        child: Center(
                                          child: Center(
                                            child: Text(
                                              '3',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Open Sans',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.3625*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // group155KT (131:1736)
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // generatenotescqB (131:1723)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                              child: Text(
                                                'Generate Notes',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w600,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // minshbj (131:1724)
                                              constraints: BoxConstraints (
                                                maxWidth: 218*fem,
                                              ),
                                              child: Text(
                                                'Save AI generated notes that can be read later.',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 15*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupqozdzaq (McvPD13REQe779s2p6Qozd)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 37*fem, 0*fem),
                                  width: double.infinity,
                                  height: 70*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // group20W3P (131:1745)
                                        margin: EdgeInsets.fromLTRB(0*fem, 21*fem, 17*fem, 19*fem),
                                        width: 30*fem,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(15*fem),
                                          gradient: LinearGradient (
                                            begin: Alignment(-1, 0),
                                            end: Alignment(1, -0),
                                            colors: <Color>[Color(0xff946cff), Color(0xff7079ff)],
                                            stops: <double>[0, 1],
                                          ),
                                        ),
                                        child: Center(
                                          child: Center(
                                            child: Text(
                                              '4',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Open Sans',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w700,
                                                height: 1.3625*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // group16gc5 (131:1737)
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // askquestionsdXK (131:1725)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                              child: Text(
                                                'Ask Questions',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w600,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // minsjaM (131:1726)
                                              constraints: BoxConstraints (
                                                maxWidth: 200*fem,
                                              ),
                                              child: Text(
                                                'Use AI to answer questions about your notes.',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 15*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse9EX7 (131:1749)
                    left: 85*fem,
                    top: 165*fem,
                    child: Align(
                      child: SizedBox(
                        width: 38*fem,
                        height: 4*fem,
                        child: Image.asset(
                          'assets/page-1/images/ellipse-9.png',
                          width: 38*fem,
                          height: 4*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // robot17au (131:1748)
                    left: 4*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 208*fem,
                        height: 208*fem,
                        child: Image.asset(
                          'assets/page-1/images/robot-1-117.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}